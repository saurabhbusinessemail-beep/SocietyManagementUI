export interface IFeature {
    featureId: string;
    featureKey: string;
    featureDescription: string;
    price: string;
}