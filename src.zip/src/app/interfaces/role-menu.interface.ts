import { IDefaultFields } from "./";

export interface IRoleMenu extends IDefaultFields {
    roleMenuId: string;
    roleId: string;
    menuId: string;
}