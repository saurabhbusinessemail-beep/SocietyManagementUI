import { IDefaultFields } from "./";

export interface IGate extends IDefaultFields {
    gateId: string;
    gateNumber: string;
    societyId: string;
}