export enum FlatTypes {
    '1BHK',
    '2BHK',
    '3BHK',
    '4BHK',
    '5BHK',
    '6BHK'
}

export const FlatTypeList = [
    FlatTypes["1BHK"],
    FlatTypes["2BHK"],
    FlatTypes["3BHK"],
    FlatTypes["4BHK"],
    FlatTypes["5BHK"],
    FlatTypes["6BHK"]
]