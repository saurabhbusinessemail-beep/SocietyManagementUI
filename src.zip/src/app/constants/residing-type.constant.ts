export enum ResidingTypes {
    'Self',
    'Tenant',
    'Vaccant'
}

export const ResidingTypeList = [
    ResidingTypes.Self,
    ResidingTypes.Tenant,
    ResidingTypes.Vaccant
]