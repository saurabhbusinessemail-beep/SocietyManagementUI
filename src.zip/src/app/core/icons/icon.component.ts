import { Component, Input, OnInit } from '@angular/core';
import { IconsService } from './icons.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-icon',
  template: `<img class="app-icon" [src]="svg" [style.color]="color">`,
  styles: [`
    .app-icon {
      display: inline-flex;
      width: 24px;
      height: 24px;
      fill: currentColor;
    }
    .app-icon svg {
      width: 100%;
      height: 100%;
    }
  `]
})
export class IconComponent implements OnInit {
  @Input() name!: string;
  @Input() color: string = '';
  svg: string | undefined;

  constructor(private iconService: IconsService, private sanitizer: DomSanitizer) {}

  ngOnInit() {
    this.svg = this.iconService.getIcon(this.name);
    // this.iconService.getIcon(this.name).subscribe(svg => {
    //   this.svg = this.sanitizer.bypassSecurityTrustHtml(svg);
    // });
  }
}

