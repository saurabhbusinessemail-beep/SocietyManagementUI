export interface IPagination {
    page?: number;
    limit?: number;
    search?: string;
    sortBy?: string;
}