export type UILabelValueType =
    | 'default'
    | 'info'
    | 'help'
    | 'active'
    | 'inactive'
    | 'rejected'
    | 'error'
    | 'expired'
    | 'pending';