import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IPhoneContactFlat, IUIControlConfig, IUIDropdownOption, UILocationResult } from '../../../interfaces';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.scss'
})
export class AdminComponent {

  usernameConfig = {
    id: 'username',
    label: 'Username',
    placeholder: 'Enter username',
    validations: [
      { name: 'required', validator: Validators.required },
      { name: 'minlength', validator: Validators.minLength(3) }
    ],
    errorMessages: {
      required: 'Username is required',
      minlength: 'Minimum 3 characters required'
    }
  };
  textNameConfig = {
    id: 'textName',
    label: 'Text Name',
    placeholder: 'Enter username',
    helpText: 'Some Help',
    validations: [
      { name: 'required', validator: Validators.required },
      { name: 'minlength', validator: Validators.minLength(3) }
    ],
    errorMessages: {
      required: 'TextNamename is required',
      minlength: 'Minimum 3 characters required'
    }
  };

  roleConfig: IUIControlConfig = {
    id: 'role',
    label: 'Role',
    placeholder: 'Select role',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'Role is required'
    }
  };

  userSearchConfig: IUIControlConfig = {
    id: 'user',
    label: 'User',
    placeholder: 'Search User',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'User is required'
    }
  };

  locationSearchConfig: IUIControlConfig = {
    id: 'location',
    label: 'Location',
    placeholder: 'Search Location',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'Location is required'
    }
  };

  contactSearchConfig: IUIControlConfig = {
    id: 'contact',
    label: 'Contacts',
    placeholder: 'Search Contact',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'Contact is required'
    }
  };

  radioConfig: IUIControlConfig = {
    id: 'radio',
    label: 'Radio',
    placeholder: 'Search Option',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'Radio is required'
    }
  };

  permissionConfig: IUIControlConfig = {
    id: 'permission',
    label: 'Permission',
    placeholder: 'Search Option',
    validations: [
      { name: 'required', validator: Validators.required },
    ],
    errorMessages: {
      required: 'Radio is required'
    },
    helpText: 'Some Help'
  };

  settingTabsConfig: IUIControlConfig = {
    id: 'settingsTab',
    label: 'Setting Tabs'
  };

  typeLabelConfig: IUIControlConfig = {
    id: 'type',
    label: 'Type Label'
  };

  roleOptions: IUIDropdownOption[] = [
    { label: 'Admin', value: 'ADMIN' },
    { label: 'Manager', value: 'MANAGER' },
    { label: 'User', value: 'USER' }
  ];

  filteredUsers: IUIDropdownOption[] = [
    { label: 'Saurabh Kumar', value: 'USR_001' },
    { label: 'Amit Sharma', value: 'USR_002' },
    { label: 'Neha Verma', value: 'USR_003' },
    { label: 'Rohit Mehta', value: 'USR_004' },
    { label: 'Pooja Singh', value: 'USR_005' }
  ];

  radioOptions: IUIDropdownOption[] = [
    { label: 'Active', value: 'ACTIVE' },
    { label: 'Inactive', value: 'INACTIVE' }
  ];

  permissionOptions: IUIDropdownOption[] = [
    { label: 'Read', value: 'read' },
    { label: 'Write', value: 'write' },
    { label: 'Delete', value: 'delete' }
  ];

  tabsOptions: IUIDropdownOption[] = [
    {
      value: 'profile',
      label: 'Profile'
    },
    {
      value: 'security',
      label: 'Security'
    },
    {
      value: 'notifications',
      label: 'Notifications'
    }
  ];

  fb = new FormGroup({
    location: new FormControl<UILocationResult | undefined>(undefined),
    userName: new FormControl({ value: 'Hello', disabled: true }),
    textName: new FormControl('Hello'),
    contacts: new FormControl<IPhoneContactFlat | undefined>(undefined),
    role: new FormControl({ value: '', disabled: false }),
    user: new FormControl<IUIDropdownOption | undefined>({ value: undefined, disabled: false }),
    status: new FormControl({ value: undefined, disabled: false }),
    statusH: new FormControl({ value: undefined, disabled: false }),
    permissions: new FormControl({ value: undefined, disabled: false }),
    permissionsH: new FormControl({ value: undefined, disabled: false }),
    settingsTab: new FormControl({ value: 'profile', disabled: false }),
    type: new FormControl('avctive'),
  })

  onUserSearch(text: string) { }
}
