export enum ComplaintTypes {
    'Public',
    'Private'
}

export const ComplaintTypeList = [
    ComplaintTypes.Public,
    ComplaintTypes.Private
];