export enum VehicleTypes {
    '2 Wheeler',
    '3 Wheeler',
    '4 Wheeler',
    '6 Wheeler'
}

export const VehicleTypeList = [
    {
        vehicleTypeId: '2W',
        name: VehicleTypes["2 Wheeler"],
        icon: ''
    },
    {
        vehicleTypeId: '3W',
        name: VehicleTypes["2 Wheeler"],
        icon: ''
    },
    {
        vehicleTypeId: '4W',
        name: VehicleTypes["2 Wheeler"],
        icon: ''
    },
    {
        vehicleTypeId: '6W',
        name: VehicleTypes["2 Wheeler"],
        icon: ''
    }
]