export interface IDefaultFields {
    createdOn: Date;
    craetedByUserId: string;
    modifiedOn?: Date;
    modifiedByUserId?: string;
    isDeleted?: boolean;
}