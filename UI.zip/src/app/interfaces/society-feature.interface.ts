import { IDefaultFields } from "./";

export interface ISocietyFeature extends IDefaultFields {
    societyFeatureId: string;
    societyId: string;
    featureKey: string;
}