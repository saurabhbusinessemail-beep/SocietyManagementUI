export interface IPhoneContactFlat {
    contactId: string;
    name: string;
    phoneNumber: string;
}