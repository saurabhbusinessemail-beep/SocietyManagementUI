import { IDefaultFields } from "./";

export interface IGateEntryLog extends IDefaultFields {
    gateEntryLogId: string;
    gatePassId: string;
}