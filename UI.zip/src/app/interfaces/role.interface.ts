import { IDefaultFields } from "./";

export interface IRole extends IDefaultFields {
    roleId: string;
    roleName: string;
}