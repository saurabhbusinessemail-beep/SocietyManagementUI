import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TextBoxComponent } from './text-box/text-box.component';
import { FormsModule } from '@angular/forms';
import { DropDownComponent } from './drop-down/drop-down.component';
import { SearchBoxComponent } from './search-box/search-box.component';
import { IconModule } from '../icons/icon.module';
import { RadioListComponent } from './radio-list/radio-list.component';
import { CheckListComponent } from './check-list/check-list.component';
import { TabsComponent } from './tabs/tabs.component';
import { UITabContentDirective } from './tabs/ui-tab-directive';
import { LabelComponent } from './label/label.component';
import { ButtonComponent } from './button/button.component';
import {MatRippleModule} from '@angular/material/core';



@NgModule({
  declarations: [
    TextBoxComponent,
    DropDownComponent,
    SearchBoxComponent,
    RadioListComponent,
    CheckListComponent,
    TabsComponent,
    UITabContentDirective,
    LabelComponent,
    ButtonComponent
  ],
  imports: [
    CommonModule, FormsModule, IconModule, MatRippleModule
  ],
  exports: [TextBoxComponent, DropDownComponent, SearchBoxComponent, RadioListComponent, CheckListComponent, TabsComponent,
    UITabContentDirective, LabelComponent, ButtonComponent]
})
export class UiModule { }
