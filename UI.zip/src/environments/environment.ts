export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000/api/v1',
  googleMapsAPIKey: 'AIzaSyCKmnbWMEfLyMYsW8K4GVAqeL_OsqtespE', // 'AIzaSyASef_eQn4ThvxBhviL3mYFk9kr2btU48I'
};
