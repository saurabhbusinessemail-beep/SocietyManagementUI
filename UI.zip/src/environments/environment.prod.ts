export const environment = {
  production: true,
  apiBaseUrl: 'https://society-management-be.vercel.app/api/v1',
};
