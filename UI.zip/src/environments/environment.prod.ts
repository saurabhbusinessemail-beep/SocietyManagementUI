export const environment = {
  production: true,
  apiBaseUrl: 'https://society-management-be.vercel.app/api/v1',
  googleMapsAPIKey: 'AIzaSyCKmnbWMEfLyMYsW8K4GVAqeL_OsqtespE', // 'AIzaSyASef_eQn4ThvxBhviL3mYFk9kr2btU48I'
};
